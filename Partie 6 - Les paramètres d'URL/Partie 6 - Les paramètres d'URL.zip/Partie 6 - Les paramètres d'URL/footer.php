<!-- Mise en place du footer à inclure dans chaque fichier PHP. -->

</body>

</html>