<!-- Enoncé : avec le formulaire de l'exercice 2, afficher dans la page user.php les données du formulaire transmises. -->


<!-- Création de variables et insertion du header et de la barre de navigation. -->

<?php
$titre = 'Exercice 4';
include 'header.php';
?>

<p>Cf. l'exercice 2.</p>

<!-- Insertion du footer. -->

<?php include 'footer.php';?>