<!-- Enoncé : avec le formulaire de l'exercice 1, afficher dans la page user.php les données du formulaire transmis. -->


<!-- Création de variables et insertion du header et de la barre de navigation. -->

<?php
$titre = 'Exercice 3';
include 'header.php';
?>

<p>Cf. l'exercice 1.</p>

<!-- Insertion du footer. -->

<?php include 'footer.php';?>