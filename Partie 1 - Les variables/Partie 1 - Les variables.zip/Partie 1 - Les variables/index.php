<!-- Mise en place de l'index au niveau de la page d'accueil du localhost. -->

<?php

include 'header.php';
?>

<?php include 'footer.php'; ?>